package com.econest;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            DeliveryManagement management =
                    new DeliveryManagement();

            management.setVisible(true);

        });

    }

}