package com.econest;

public class DeliveryAgent {

    private int agentId;

    private String agentName;

    private String email;

    private String phone;

    private String vehicleNumber;

    private String vehicleType;


    public DeliveryAgent(int agentId, String agentName,
                         String email, String phone,
                         String vehicleNumber,
                         String vehicleType) {

        this.agentId = agentId;

        this.agentName = agentName;

        this.email = email;

        this.phone = phone;

        this.vehicleNumber = vehicleNumber;

        this.vehicleType = vehicleType;

    }


    public int getAgentId() {
        return agentId;
    }


    public String getAgentName() {
        return agentName;
    }


    public String getEmail() {
        return email;
    }


    public String getPhone() {
        return phone;
    }


    public String getVehicleNumber() {
        return vehicleNumber;
    }


    public String getVehicleType() {
        return vehicleType;
    }


    @Override
    public String toString() {

        return agentName + " - " + vehicleNumber;

    }

}