package com.econest;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class DeliveryManagement extends JFrame {


    private JComboBox<Integer> orderBox;

    private JComboBox<DeliveryAgent> agentBox;

    private JTextField dateField;

    private JTable assignmentTable;

    private DefaultTableModel tableModel;

    private JComboBox<String> statusBox;


    private DeliveryAgentDAO agentDAO =
            new DeliveryAgentDAO();

    private DeliveryAssignmentDAO assignmentDAO =
            new DeliveryAssignmentDAO();


    public DeliveryManagement() {

        setTitle("EcoNest - Delivery Management");

        setSize(850, 600);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());


        // TOP PANEL

        JPanel topPanel = new JPanel(
                new GridLayout(5, 2, 10, 10)
        );

        topPanel.setBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );


        orderBox = new JComboBox<>();

        agentBox = new JComboBox<>();

        dateField = new JTextField();


        JButton assignButton =
                new JButton("Assign Delivery");


        topPanel.add(new JLabel("Select Order:"));

        topPanel.add(orderBox);


        topPanel.add(new JLabel("Select Delivery Agent:"));

        topPanel.add(agentBox);


        topPanel.add(new JLabel("Delivery Date (YYYY-MM-DD):"));

        topPanel.add(dateField);


        topPanel.add(new JLabel(""));

        topPanel.add(assignButton);


        // TABLE

        String[] columns = {

            "Assignment ID",

            "Order ID",

            "Agent Name",

            "Vehicle Number",

            "Delivery Date",

            "Status"

        };


        tableModel = new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {

                return false;

            }

        };


        assignmentTable = new JTable(tableModel);


        JScrollPane scrollPane =
                new JScrollPane(assignmentTable);


        // STATUS PANEL

        JPanel bottomPanel = new JPanel();


        statusBox = new JComboBox<>(new String[]{

            "Assigned",

            "Picked Up",

            "In Transit",

            "Delivered",

            "Cancelled"

        });


        JButton updateButton =
                new JButton("Update Delivery Status");


        bottomPanel.add(new JLabel("New Status:"));

        bottomPanel.add(statusBox);

        bottomPanel.add(updateButton);


        add(topPanel, BorderLayout.NORTH);

        add(scrollPane, BorderLayout.CENTER);

        add(bottomPanel, BorderLayout.SOUTH);


        // BUTTON ACTIONS

        assignButton.addActionListener(e -> assignDelivery());

        updateButton.addActionListener(e -> updateStatus());


        // LOAD DATA

        loadOrders();

        loadAgents();

        loadAssignments();


    }


    // LOAD ORDERS

    private void loadOrders() {

        orderBox.removeAllItems();

        ArrayList<Integer> orders =
                assignmentDAO.getAvailableOrders();


        for (Integer order : orders) {

            orderBox.addItem(order);

        }

    }


    // LOAD AGENTS

    private void loadAgents() {

        agentBox.removeAllItems();

        ArrayList<DeliveryAgent> agents =
                agentDAO.getAllAgents();


        for (DeliveryAgent agent : agents) {

            agentBox.addItem(agent);

        }

    }


    // ASSIGN DELIVERY

    private void assignDelivery() {

        try {

            Integer orderId =
                    (Integer) orderBox.getSelectedItem();

            DeliveryAgent agent =
                    (DeliveryAgent) agentBox.getSelectedItem();


            String date = dateField.getText().trim();


            if (orderId == null || agent == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please select an order and delivery agent."
                );

                return;

            }


            java.sql.Date.valueOf(date);


            boolean success =
                    assignmentDAO.assignDelivery(
                            orderId,
                            agent.getAgentId(),
                            date
                    );


            if (success) {

                boolean emailSent =
                        EmailService.sendAssignmentEmail(
                                agent.getEmail(),
                                agent.getAgentName(),
                                orderId,
                                date
                        );


                if (emailSent) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Delivery Assigned Successfully!\n" +
                            "Email notification sent to " +
                            agent.getEmail()
                    );

                } else {

                    JOptionPane.showMessageDialog(
                            this,
                            "Delivery assigned successfully, " +
                            "but the email could not be sent.\n" +
                            "Please check the email configuration."
                    );

                }


                loadOrders();

                loadAssignments();

                dateField.setText("");


            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Delivery Assignment Failed!"
                );

            }


        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid date (YYYY-MM-DD)."
            );

        }

    }


    // UPDATE DELIVERY STATUS

    private void updateStatus() {

        int selectedRow =
                assignmentTable.getSelectedRow();


        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a delivery assignment."
            );

            return;

        }


        int assignmentId = Integer.parseInt(
                tableModel.getValueAt(
                        selectedRow, 0
                ).toString()
        );


        String status =
                statusBox.getSelectedItem().toString();


        boolean success =
                assignmentDAO.updateStatus(
                        assignmentId,
                        status
                );


        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Delivery Status Updated Successfully!"
            );

            loadAssignments();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Status Update Failed!"
            );

        }

    }


    // LOAD ASSIGNMENTS INTO TABLE

    private void loadAssignments() {

        tableModel.setRowCount(0);


        ArrayList<String[]> assignments =
                assignmentDAO.getAllAssignments();


        for (String[] row : assignments) {

            tableModel.addRow(row);

        }

    }


}