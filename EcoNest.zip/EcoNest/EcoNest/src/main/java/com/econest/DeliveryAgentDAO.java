package com.econest;

import java.sql.*;
import java.util.ArrayList;

public class DeliveryAgentDAO {

    public ArrayList<DeliveryAgent> getAllAgents() {

        ArrayList<DeliveryAgent> agents = new ArrayList<>();

        String sql = "SELECT * FROM delivery_agents";

        try (
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql);

            ResultSet rs = pst.executeQuery()
        ) {

            while (rs.next()) {

                DeliveryAgent agent = new DeliveryAgent(

                    rs.getInt("agent_id"),

                    rs.getString("agent_name"),

                    rs.getString("email"),

                    rs.getString("phone"),

                    rs.getString("vehicle_number"),

                    rs.getString("vehicle_type")

                );

                agents.add(agent);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return agents;
    }
}