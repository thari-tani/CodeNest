package com.econest;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailService {


    public static boolean sendAssignmentEmail(
            String receiverEmail,
            String agentName,
            int orderId,
            String deliveryDate) {


        final String senderEmail =
                System.getenv("ECONEST_EMAIL");

        final String appPassword =
                System.getenv("ECONEST_APP_PASSWORD");


        if (senderEmail == null || appPassword == null) {

            System.out.println("Email credentials are missing.");

            return false;

        }


        Properties properties = new Properties();

        properties.put("mail.smtp.auth", "true");

        properties.put("mail.smtp.starttls.enable", "true");

        properties.put("mail.smtp.host", "smtp.gmail.com");

        properties.put("mail.smtp.port", "587");


        Session session = Session.getInstance(
            properties,

            new Authenticator() {

                @Override
                protected PasswordAuthentication
                getPasswordAuthentication() {

                    return new PasswordAuthentication(
                        senderEmail,
                        appPassword
                    );

                }

            }
        );


        try {

            Message message = new MimeMessage(session);

            message.setFrom(new InternetAddress(senderEmail));

            message.setRecipients(
                Message.RecipientType.TO,
                InternetAddress.parse(receiverEmail)
            );

            message.setSubject(
                "New Delivery Assignment - EcoNest"
            );


            String emailContent =

                "Dear " + agentName + ",\n\n" +

                "You have been assigned a new delivery by EcoNest.\n\n" +

                "Order ID: " + orderId + "\n" +

                "Scheduled Delivery Date: " + deliveryDate + "\n\n" +

                "Please check your delivery schedule and prepare " +
                "for the assigned delivery.\n\n" +

                "Thank you.\n\n" +

                "EcoNest Delivery Management Team";


            message.setText(emailContent);


            Transport.send(message);

            System.out.println("Email sent successfully!");

            return true;


        } catch (MessagingException e) {

            e.printStackTrace();

            return false;

        }

    }

}