package com.econest;

import java.sql.*;
import java.util.ArrayList;

public class DeliveryAssignmentDAO {


    // Get orders that have not been assigned

    public ArrayList<Integer> getAvailableOrders() {

        ArrayList<Integer> orders = new ArrayList<>();

        String sql =
            "SELECT o.order_id FROM orders o " +
            "LEFT JOIN delivery_assignments d " +
            "ON o.order_id = d.order_id " +
            "WHERE d.order_id IS NULL";


        try (
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql);

            ResultSet rs = pst.executeQuery()
        ) {

            while (rs.next()) {

                orders.add(rs.getInt("order_id"));

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return orders;
    }


    // Assign delivery agent to order

    public boolean assignDelivery(int orderId,
                                  int agentId,
                                  String date) {

        String sql =
            "INSERT INTO delivery_assignments " +
            "(order_id, agent_id, scheduled_date, delivery_status) " +
            "VALUES (?, ?, ?, 'Assigned')";


        try (
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql)
        ) {

            pst.setInt(1, orderId);

            pst.setInt(2, agentId);

            pst.setDate(3, Date.valueOf(date));

            int result = pst.executeUpdate();

            return result > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;

        }

    }


    // Update delivery status

    public boolean updateStatus(int assignmentId,
                                String status) {

        String sql =
            "UPDATE delivery_assignments " +
            "SET delivery_status = ? " +
            "WHERE assignment_id = ?";


        try (
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql)
        ) {

            pst.setString(1, status);

            pst.setInt(2, assignmentId);

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;

        }

    }


    // Display all delivery assignments

    public ArrayList<String[]> getAllAssignments() {

        ArrayList<String[]> assignments = new ArrayList<>();

        String sql =
            "SELECT d.assignment_id, d.order_id, " +
            "a.agent_name, a.vehicle_number, " +
            "d.scheduled_date, d.delivery_status " +

            "FROM delivery_assignments d " +

            "JOIN delivery_agents a " +
            "ON d.agent_id = a.agent_id";


        try (
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql);

            ResultSet rs = pst.executeQuery()
        ) {

            while (rs.next()) {

                String[] row = {

                    String.valueOf(rs.getInt("assignment_id")),

                    String.valueOf(rs.getInt("order_id")),

                    rs.getString("agent_name"),

                    rs.getString("vehicle_number"),

                    rs.getString("scheduled_date"),

                    rs.getString("delivery_status")

                };

                assignments.add(row);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return assignments;
    }

}