package com.econest;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            ProcessOrderFrame frame =
                    new ProcessOrderFrame();

            frame.setVisible(true);

        });

    }

}